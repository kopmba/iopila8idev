package waz.utils;

import java.lang.reflect.Method;
import java.util.Map;

public class CryptoUtil {
	
	/**
	 * Retrieves input commitment
	 * @param msg : some message
	 * @param nonce : secret random value
	 */
	public static String commit(String msg, String nonce) {
		return "";
	}
	
	/**
	 * Verify the securities properties : 
	 * Hiding where when a secret value is chosen, it is infeasible to find msg
	 * Binding where it is infeasible to find two pairs with the condition
	 * (msg, nonce) and (x,y).
	 * @param msg : some message
	 * @param nonce : secret random value
	 * @param callback : the commitment
	 */
	public static void verify(String msg, String nonce, Method callback) {
		
	}
	
	/**
	 * Generates a map to sign messages and verify signature.
	 * @param size : the size of the key
	 * @return Map : the pair {sk, pk}
	 */
	public static Map generateKeys(int size) {
		return null;
	}
	
	/**
	 * Retrieves the input of the message sign
	 * @param sk : secret key
	 * @param msg : some message
	 * @return a signature
	 */
	public static String sign(String sk, String msg) {
		return "";
	}
	
	/**
	 * Verify the authencity of the input using the public key.
	 * @param pk : public key
	 * @param msg : some message
	 * @param sig : a signature
	 * @return boolean
	 */
	public static boolean verify(String pk, String msg, String sig) {
		return false;
	}
	
	/**
	 * 
	 * @param amount : the claiming amount
	 * @param nonce : secret random value
	 * @param sig : signature
	 */
	public static void claimPayment(double amount, String nonce, String sig) {
		
	}
	
	/**
	 * 
	 * @param msg : message
	 * @param sig : signature
	 * @return
	 */
	public static String recoverSigner(String msg, String sig) {
		return "";
	}
	
	/**
	 * 
	 * @param hash : hash value
	 * @return
	 */
	public static String prefixed(String hash) {
		return "";
	}

}
