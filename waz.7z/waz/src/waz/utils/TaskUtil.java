package waz.utils;

public class TaskUtil {
	
	public static final String CREATE_CONTRACT = "";
	public static final String GET_CONTRACT = "";
	public static final String GET_CONTRACTs = "";
	
	public static final String CREATE = "";
	public static final String ONE = "";
	public static final String GET = "";

}
