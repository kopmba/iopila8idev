package waz.error;

public class TimeExpireError extends Exception {
	
	/**
	 * Send exception with message expire time error.
	 * @param msg
	 */
	public void retry(MessageError msg) {
		
	}

}
