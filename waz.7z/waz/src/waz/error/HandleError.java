package waz.error;

public class HandleError<T> {
	
	/**
	 * Generate issue error by manipulating an object
	 * @param o : The object we handling
	 * @param e : The exception
	 */
	public void handleIssue(T o, Exception e) {
		
	}

}
