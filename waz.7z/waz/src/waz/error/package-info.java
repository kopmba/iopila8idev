/**
 * 
 */
/**
 * @author root
 *
 */
package waz.error;