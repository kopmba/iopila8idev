package waz.error;

public class RightError extends Exception {
	
	/**
	 * Send Exception with printStack message.
	 */
	public void none() {
		
	}

}
