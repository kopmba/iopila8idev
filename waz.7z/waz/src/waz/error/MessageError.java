package waz.error;

public class MessageError {
	
	/**
	 * Send Message when time expires.
	 * @return
	 */
	public String timeExpire() {
		return "";
	}
	
	/**
	 * Send message when any subscriber doesn't have right on voting or validation.
	 * @return
	 */
	public String none() {
		return "";
	}

}
