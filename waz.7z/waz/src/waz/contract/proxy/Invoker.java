package waz.contract.proxy;

import waz.event.EventHandler;

public interface Invoker extends EventHandler {
	
	/**
	 * Invoke the service query to handle the proxy notifier
	 * @param proxy
	 * @return
	 */
	public Object invoke(UserProxy proxy);

}
