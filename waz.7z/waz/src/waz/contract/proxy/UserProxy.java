/**
 * 
 */
package waz.contract.proxy;

/**
 * @author Steve Mbakop
 *
 */
public class UserProxy implements ContractObserver {

	@Override
	public void notifyChange() {
		
	}

}
