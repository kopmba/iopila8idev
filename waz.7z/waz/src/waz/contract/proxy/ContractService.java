/**
 * 
 */
package waz.contract.proxy;

/**
 * @author Steve Mbakop
 *
 */
public interface ContractService {
	
	/**
	 * Retrieves the current state of any transaction contract request to notify user.
	 * @return the Map containing the request with all information
	 */
	public Object query();

}
