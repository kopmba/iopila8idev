package waz.contract.proxy;

public class AutomatedStruct implements ContractObserver {

	@Override
	public void notifyChange() {
		
	}

}
