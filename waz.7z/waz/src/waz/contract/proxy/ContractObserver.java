/**
 * 
 */
package waz.contract.proxy;

/**
 * @author Steve Mbakop
 *
 */
public interface ContractObserver {
	
	/**
	 * Notify the admin when any contract lifecycle is operating.
	 */
	public void notifyChange();

}
