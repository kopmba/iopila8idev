/**
 * 
 */
/**
 * @author root
 *
 */
package waz.contract.proxy;