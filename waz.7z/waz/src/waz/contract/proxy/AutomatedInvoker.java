/**
 * 
 */
package waz.contract.proxy;

/**
 * @author Steve Mbakop
 *
 */
public class AutomatedInvoker implements Invoker {

	@Override
	public Object invoke(UserProxy proxy) {
		return null;
	}

	@Override
	public void onCreateEvent(Object entity) {
		
	}

	@Override
	public void onGetEvent(Object entity) {
		
	}


}
