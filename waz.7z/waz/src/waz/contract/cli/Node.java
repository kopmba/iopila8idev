package waz.contract.cli;

import java.util.LinkedList;

public class Node {
	
	private final LinkedList list;
	private Leaf value;
	
	/**
	 * Create a composite by adding children corresponding at the
	 * pair of Nodes.
	 * @param list
	 */
	public Node(LinkedList list) {
		this.list = list;
	}
	
	/**
	 * Create list of pair to add to the Node.
	 * This method creates Leaf to specify the level
	 * of any Tree.
	 * @param o1
	 * @param o2
	 */
	public void add(Object o1, Object o2) {
		
	}
	
	public LinkedList getList() {
		return list;
	}
	
	public Leaf getValue() {
		return value;
	}
	
	public void setValue(Leaf value) {
		this.value = value;
	}

}
