/**
 * This package contains the classes allowing the launch process
 * of any task when execute any contract.
 */
/**
 * @author Steve Mbakop
 *
 */
package waz.contract.cli;