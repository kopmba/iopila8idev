/**
 * 
 */
package waz.contract.cli;

import waz.config.builder.WazEntity;

/**
 * The Contract extends 
 * @author Steve Mbakop
 *
 */
public abstract class Contract {
	
	private final long id;
	private final String sig;
	private final String nonce;
	private final String cfile;
	
	/**
	 * Build a Contract to use a DbState factory in CRUD mode.
	 * @param builder
	 * @param id
	 * @param sig
	 * @param nonce
	 * @param cfile
	 */
	public Contract(long id, String sig, String nonce, String cfile) {
		super();
		this.id = id;
		this.sig = sig;
		this.nonce = nonce;
		this.cfile = cfile;
	}
	
	/**
	 * Retrieves the the contract id.
	 * @return the specified id
	 */
	public long getId() {
		return id;
	}
	
	/**
	 * Retrieves the contract signature.
	 * @return the specified signature.
	 */
	public String getSig() {
		return sig;
	}
	
	/**
	 * Retrieves the contract nonce.
	 * @return the specified nonce.
	 */
	public String getNonce() {
		return nonce;
	}
	
	/**
	 * Retrieves the contract file url.
	 * @return the specified file uri.
	 */
	public String getCfile() {
		return cfile;
	}
	
	/**
	 * Abstract method to specify a contract.
	 * The document allow 5 types : ["Vote", "Validate", "Payment|Token", "Payable", "Auction"]
	 * @param name : the name specifying the contract type.
	 * @return the Contract with its specified name.
	 */
	public abstract Contract valueOf(String name);

}
