package waz.contract.cli;

import java.util.LinkedList;

public class Leaf {
	
	private final Node parent;
	private final LinkedList<Node> children;
	private final int level;
	
	/**
	 * Construct a node by giving its params
	 * @param parent
	 * @param children
	 * @param level
	 */
	public Leaf(Node parent, LinkedList<Node> children, int level) {
		super();
		this.parent = parent;
		this.children = children;
		this.level = level;
	}
	
	/**
	 * Retrieves the parent of this Node.
	 * @return the specified parent.
	 */
	public Node getParent() {
		return parent;
	}
	
	/**
	 * Retrieves the children of this Node. 
	 * @return the specified children.
	 */
	public LinkedList<Node> getChildren() {
		return children;
	}
	
	/**
	 * Retrieves the level of this Node.
	 * The level is specific to the tree.
	 * @return the specified level.
	 */
	public int getLevel() {
		return level;
	}

}
