/**
 * 
 */
package waz.contract.cli;

import java.time.Instant;
import java.util.concurrent.atomic.AtomicInteger;

import main.config.builder.Entity;
import main.config.builder.Entity.EntityBuilder;

/**
 * This class extends Entity to manage the state object
 * used to create and retrieves object. 
 * @author Steve Mbakop
 *
 */
public class WazTransaction extends Entity {
	
	private static final AtomicInteger ID = new AtomicInteger();
	
	private final int id;
	private final Instant tdate;
	private final Object from;
	private final Object to;
	private final Contract contract;
	
	/**
	 * Construct a transaction to add in some Node.
	 * @param id
	 * @param tdate
	 * @param from
	 * @param to
	 * @param c
	 */
	public WazTransaction(EntityBuilder builder, int id, Instant tdate, Object from, Object to, Contract c) {
		super(builder);
		this.id = ID.incrementAndGet();
		this.tdate = tdate;
		this.from = from;
		this.to = to;
		this.contract = c;
	}

	public Object getFrom() {
		return from;
	}

	public Object getTo() {
		return to;
	}

	public int getId() {
		return id;
	}

	public Instant getTdate() {
		return tdate;
	}
	
	public Contract getContract() {
		return contract;
	}

	@Override
	public String toString() {
		return "Transaction [id=" + id + ", tdate=" + tdate + ", from=" + from + ", to=" + to + " contract=" + contract + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((from == null) ? 0 : from.hashCode());
		result = prime * result + (int) (id ^ (id >>> 32));
		result = prime * result + ((tdate == null) ? 0 : tdate.hashCode());
		result = prime * result + ((to == null) ? 0 : to.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		WazTransaction other = (WazTransaction) obj;
		if (from == null) {
			if (other.from != null)
				return false;
		} else if (!from.equals(other.from))
			return false;
		if (id != other.id)
			return false;
		if (tdate == null) {
			if (other.tdate != null)
				return false;
		} else if (!tdate.equals(other.tdate))
			return false;
		if (to == null) {
			if (other.to != null)
				return false;
		} else if (!to.equals(other.to))
			return false;
		if (contract == null) {
			if (other.contract != null)
				return false;
		} else if (!contract.equals(other.contract))
			return false;
		return true;
	}
	
	

}
