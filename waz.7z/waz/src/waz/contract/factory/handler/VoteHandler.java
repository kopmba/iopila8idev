/**
 * 
 */
package waz.contract.factory.handler;

import waz.contract.factory.TopicSubject;
import waz.contract.factory.service.VotingService;

/**
 * @author Steve Mbakop
 *
 */
public class VoteHandler extends VotingService {
	
	/**
	 * Vote given by one Subscriber
	 */
	@Override
	public void vote(TopicSubject subject) {
		
	}

}
