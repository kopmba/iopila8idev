/**
 * 
 */
package waz.contract.factory.handler;

import waz.contract.factory.TopicSubject;
import waz.contract.factory.service.ValidationService;

/**
 * @author Steve Mbakop
 *
 */
public class ValidationHandler extends ValidationService {
	
	/**
	 * Validation given by one Subscriber
	 */
	@Override
	public void validate(TopicSubject subject) {
		
	}
	
	/**
	 * Vote given by one Subscriber
	 */
	@Override
	public void vote(TopicSubject subject) {
		
	}

}
