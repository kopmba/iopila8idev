/**
 * 
 */
package waz.contract.factory;

import java.util.concurrent.Flow;

/**
 * As subject, the Contract Publisher is used to perform
 * operation made or demand by users to execute many
 * types of unit transactions. 
 * @author Steve Mbakop
 *
 */
public abstract class ContractPublisher extends ContractFactory implements Flow.Publisher {
	
	/**
	 * Add subscriber to the list of subscribers and broadcast other subscribers
	 * @param o : the specified object
	 */
	public abstract void attach(Object o);
	
	/**
	 * Removes subscriber to the list of subscribers and broadcast the network
	 * if the parameter boolean its true.
	 * @param o : the specified object
	 * @param alert : the alerting state
	 */
	public abstract void detach(Object o, boolean alert);
	
	/**
	 * Gives right access to a subscriber. 
	 * @param o : the specified object
	 */
	public abstract void addRight(Object o);
	
	/**
	 * Delegates responsability to a subscriber.
	 * @param o : the specified object
	 */
	public abstract void delegate(Object o);
	
	/**
	 * Removes subscriber from a specified network.
	 */
	public abstract void unsubscribe();

}
