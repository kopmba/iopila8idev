/**
 * 
 */
package waz.contract.factory;

import java.util.Collection;

import waz.contract.cli.Contract;
import waz.contract.cli.WazTransaction;
import waz.contract.cli.WazTransaction;
import waz.contract.proxy.ContractService;
import waz.event.EntityEventHandler;

/**
 * The factory is a contract used to create transaction using the 
 * pattern Dao.
 * @author Steve Mbakop
 *
 */
public abstract class ContractFactory extends EntityEventHandler implements ContractService {
	
	/**
	 * Create a new transaction
	 * @param transaction
	 */
	public void add(WazTransaction transaction) {
		
	}
	
	/**
	 * Retrieves contract by the specified id.
	 * @param tid
	 * @return the specified transcation.
	 */
	public WazTransaction get(int tid) {
		return null;
	}
	
	/**
	 * Retrieves contract by the transaction id
	 * @param tid
	 * @return the specified Contract
	 */
	public Contract getByTransactionId(int tid) {
		return null;
	}
	
	/**
	 * Retrieves all the transactions.
	 * @return the transaction list.
	 */
	public Collection<WazTransaction> findAll() {
		return null;
	}
	
	/**
	 * Retrieves all the transactions by its contract name.
	 * @return the transaction list.
	 */
	public Collection<WazTransaction> find(String contractName) {
		return null;
	}
	
	/**
	 * Retrieves all the contract.
	 * @return the transaction list.
	 */
	public Collection<Contract> find() {
		return null;
	}


}
