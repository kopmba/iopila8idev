package waz.contract.factory;

import java.util.concurrent.Flow;

import waz.pool.QueueDB;

/**
 * The Contract Subscriber is the observer used
 * to broadcast event made by subscribers.
 * @author Steve Mbakop
 *
 */
public interface ContractSubscriber extends Flow.Subscriber {
	
	/**
	 * Set the state of this subscriber.
	 */
	public void update();
	
	/**
	 * Broadcast other subscribers to the network and send notification.
	 * The notification is stored in DB.
	 * @param list
	 */
	public void emit(QueueDB list);
	

}
