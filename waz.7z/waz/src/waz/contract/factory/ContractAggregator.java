/**
 * 
 */
package waz.contract.factory;

import java.util.Collection;

/**
 * @author Steve Mbakop
 *
 */
public abstract class ContractAggregator extends ContractFactory {
	
	/**
	 * Retrieves the collection store in file.
	 * @param cName
	 * @return
	 */
	public abstract Collection getCollection(String cName);

}
