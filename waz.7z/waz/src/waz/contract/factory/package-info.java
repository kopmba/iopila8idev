/**
 * 
 */
/**
 * @author root
 *
 */
package waz.contract.factory;