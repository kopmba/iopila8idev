/**
 * 
 */
package waz.contract.factory;

import java.util.concurrent.Flow.Subscription;

import waz.pool.QueueDB;

/**
 * Concrete Observer who observes the subject and perform
 * operation bound to the subject specification.
 * @author Steve Mbakop
 *
 */
public class Subscriber implements ContractSubscriber {

	@Override
	public void update() {
		
	}

	@Override
	public void emit(QueueDB list) {
		
	}

	@Override
	public void onSubscribe(Subscription subscription) {
		
	}

	@Override
	public void onNext(Object item) {
		
	}

	@Override
	public void onError(Throwable throwable) {
		
	}

	@Override
	public void onComplete() {
		
	}
	
	

}
