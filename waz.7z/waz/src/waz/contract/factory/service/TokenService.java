package waz.contract.factory.service;

import waz.event.EntityEventHandler;
import waz.event.EventHandler;

public class TokenService<T> extends EntityEventHandler<T> {
	
	/**
	 * Transfer amount to some user 'to'.
	 * @param to : The receiver
	 * @param amount : The transferred amount
	 */
	public void transfer(Object to, double amount) {
		
	}
	
	/**
	 * Transfer the amount to some user 'to' specifying the sender 'from'.
	 * @param from : The sender
	 * @param to : The receiver
	 * @param amount : The amount sent
	 */
	public void transferFrom(Object from, Object to, double amount) {
		
	}
	
	/**
	 * Approves the token sent by the sender
	 * @param sender
	 * @param token
	 */
	public boolean approve(Object sender, T token) {
		return false;
	}
	
	/**
	 * Retrieves the balance amount of some owner
	 * @param tokenOwner
	 */
	public double balanceOf(Object tokenOwner) {
		return 0.00;
	}

}
