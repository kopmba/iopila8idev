/**
 * 
 */
package waz.contract.factory.service;

import java.util.Collection;
import java.util.Map;

import waz.contract.factory.Subscriber;
import waz.contract.factory.TopicSubject;

/**
 * @author Steve Mbakop
 *
 */
public abstract class VotingService<T> extends TopicSubject {
	
	/**
	 * Build a list of subjects a subscriber have to vote.
	 * Every subject will be notify regarding to the right
	 * specific to the corresponding subscriber. 
	 * @param subjects
	 * @return the pair {subscriber, list}
	 */
	public Map<Subscriber, Collection> factory(Collection subjects) {
		return null;
	}
	
	/**
	 * Retrieves the winning subject of the voting election.
	 * @return the winiing subject
	 */
	public Object winningSubject() {
		return null;
	}
	
	/**
	 * Retrieves the winner of the voting election
	 * @return the winner
	 */
	public Object winner() {
		return null;
	}
	
	/**
	 * Abstract method to handle vote
	 * @param subject
	 */
	public abstract void vote(TopicSubject subject);

}
