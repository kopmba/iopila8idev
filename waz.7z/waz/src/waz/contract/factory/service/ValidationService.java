/**
 * 
 */
package waz.contract.factory.service;

import waz.contract.factory.TopicSubject;

/**
 * @author Steve Mbakop
 *
 */
public abstract class ValidationService<T> extends VotingService {
	
	/**
	 * Abstract method to handle validation
	 * @param subject
	 */
	public abstract void validate(TopicSubject subject);

}
