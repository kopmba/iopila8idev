package waz.contract.factory.service;

import waz.event.EntityEventHandler;
import waz.event.EventHandler;

public class PayableService<T> extends EntityEventHandler<T> {
	
	/**
	 * Abort the request
	 */
	public void abort() {
		
	}
	
	/**
	 * Confirm the purchase request
	 */
	public void confirmPurchase() {
		
	}
	
	/**
	 * Confirm the received request
	 */
	public void confirmReceived() {
		
	}
	
	/**
	 * Refund the amount to some seller
	 * @param seller
	 */
	public void refund(Object seller) {
		
	}

}
