/**
 * 
 */
package waz.contract.factory;

import java.util.concurrent.Flow.Subscriber;

/**
 * This class defines the real subject observed by
 * subscribers to perform operation and notify this
 * subscriber.
 * @author Steve Mbakop
 *
 */
public class TopicSubject extends ContractPublisher {

	@Override
	public Object query() {
		return null;
	}

	@Override
	public void attach(Object o) {
		
	}

	@Override
	public void detach(Object o, boolean alert) {
		
	}

	@Override
	public void addRight(Object o) {
		
	}

	@Override
	public void delegate(Object o) {
		
	}

	@Override
	public void subscribe(Subscriber subscriber) {
		
	}

	@Override
	public void unsubscribe() {
		
	}

}
