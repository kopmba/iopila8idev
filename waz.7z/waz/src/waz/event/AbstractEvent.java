package waz.event;

public abstract class AbstractEvent  implements Event {
}
