/**
 * 
 */
package waz.event;

/**
 * @author Steve Mbakop
 *
 */
public class EntityEventHandler<T> implements EventHandler<T> {

	@Override
	public void onCreateEvent(T entity) {
		
	}

	@Override
	public void onGetEvent(T entity) {
		
	}
	
	
	public void setEvent(String eventName) {
		
	}

	

}
