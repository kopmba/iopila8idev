/**
 * 
 */
package waz.event;

import waz.config.builder.WazEntity;

/**
 * @author Steve Mbakop
 *
 */
public class EntityCreateEvent<T> extends AbstractEvent {
	
	private final WazEntity we;

	public EntityCreateEvent(WazEntity we) {
		super();
		this.we = we;
	}

	@Override
	public Event getType() {
		return null;
	}
	
	public WazEntity getWe() {
		return we;
	}

}
