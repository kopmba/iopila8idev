/**
 * 
 */
package waz.event;

import waz.config.builder.WazEntity;

/**
 * @author Steve Mbakop
 *
 */
public class EntityGetEvent extends AbstractEvent {
	
	private final WazEntity we;

	public EntityGetEvent(WazEntity we) {
		super();
		this.we = we;
	}

	@Override
	public Event getType() {
		return null;
	}
	
	public WazEntity getWe() {
		return we;
	}

}
