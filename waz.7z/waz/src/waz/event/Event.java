/**
 * 
 */
package waz.event;

/**
 * @author Steve Mbakop
 *
 */
public interface Event<T> {
	
	/**
	 * Retrieves the type of this event.
	 * @return the specified type
	 */
	public Event getType();

}
