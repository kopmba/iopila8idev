/**
 * 
 */
package waz.event;

/**
 * @author Steve Mbakop
 *
 */
public class EventDispatcher<T> {
	
	/**
	 * Register any event to save the state of any record
	 * @param event
	 * @param eventHadnler
	 */
	public void registerHandler(Event<T> event, EventHandler<T> eventHandler) {
		
	}
	
	/**
	 * Broadcast the event to be queried by the contract factory in order to
	 * execute launch an update to the system, giving the profiling
	 * @param event
	 */
	public void dispatch(Event<T> event) {
		
	}

}
