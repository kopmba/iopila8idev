package waz.event;

public interface EventHandler<T> {
	
	/**
	 * Event launched when transaction is created or the system
	 * is adding new resource.
	 * @param entity
	 */
	public void onCreateEvent(T entity);
	
	/**
	 * Event launched when the system is getting a resource
	 * asked by the client or if any resource is in getting
	 * mode at the lifecycle execution.
	 * @param entity
	 */
	public void onGetEvent(T entity);

}
