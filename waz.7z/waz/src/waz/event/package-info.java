/**
 * 
 */
/**
 * @author root
 *
 */
package waz.event;