/**
 * 
 */
package waz.pool;

import java.util.Collection;
import java.util.Queue;

import waz.contract.cli.Contract;
import waz.contract.cli.Node;
import waz.contract.factory.ContractAggregator;

/**
 * @author Steve Mbakop
 * This class use the pattern Component to add data values in xml 
 * to retrieve the current state of Entity (Contract) and task created.
 * This class is the core of the framework by its capacity to create the
 * Blockchain to store all the transactions.
 */
public class QueueDB extends ContractAggregator {
	
	private Queue<QueueTask> tasks;
	private Queue<Contract> contracts;
	private Queue<Node> nodes;
	private Queue subscribers;
	
	/**
	 * Add object (Task|Contract|Node)
	 * @param o
	 */
	public void add(Object o) {
		
	}
	
	/**
	 * Retrieves an object by its id.
	 * @param id
	 * @return the specified object
	 */
	public Object retrieve(int id) {
		return  null;
	}
	
	/**
	 * Retieves the list of contracts
	 * @return FIFO list
	 */
	public Queue<Contract> getContracts() {
		return null;
	}
	
	/**
	 * Retrieves the list of tasks
	 * @return FIFO list
	 */
	public Queue<Task> getTasks() {
		return null;
	}
	
	/**
	 * Retrieves the dequeue of Nodes as LIFO and return a queue
	 * @return FIFO list
	 */
	public Queue<Node> getNodes() {
		//Retrieves the LIFO block of nodes using the root node
		return null;
	}
	
	/**
	 * Retrieves the list of subscribers in the network.
	 * @return FIFO list
	 */
	public Queue getSubscribers() {
		return null;
	}

	@Override
	public Object query() {
		return null;
	}

	@Override
	public Collection getCollection(String cName) {
		return null;
	}

}
