/**
 * 
 */
package waz.pool;

import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.SynchronousQueue;

import waz.contract.cli.Node;

/**
 * @author Steve Mbakop
 *
 */
public class WazQueue extends SynchronousQueue<Node> {
	
	private Node front;
	private Node rear;
	
	/**
	 * 
	 */
	public WazQueue() {
		super();
		this.front = (Node) dequeue().peekLast();
		this.rear = (Node) dequeue().peekFirst();
	}

	public WazQueue(boolean fair) {
		super(fair);
	}
	
	/**
	 * Queue node to linked list
	 * @return LIFO list
	 */
	public LinkedList dequeue() {
		//query the getNodes() in QueueDB
		return null;
	}
	
	/**
	 * Get the rear with children in LIFO mode and return the FIFO list.
	 * @param o
	 * @return FIFO list
	 */
	public Queue enqueue(Node o) {
		//Retrieves the LIFO block of nodes using the root node
		//set to allow the FIFO mechanism
		return null;
	}
	
	/**
	 * Push the node in rear to the Queue Block
	 * @param o
	 */
	public void push(Node o) {
		//push the corresponding node in rear to the Queue
		
	}
	
	/**
	 * Retrieve the front node.
	 */
	public Node peek() {
		return null;
	}
	
	/**
	 * Retrieves the front of this Queue.
	 * @return the specified front.
	 */
	public Node getFront() {
		return front;
	}
	
	/**
	 * Retrieves the rear of this Queue.
	 * @return the specified rear.
	 */
	public Node getRear() {
		return rear;
	}

}
