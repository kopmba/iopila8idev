/**
 * 
 */
package waz.pool;

import waz.contract.cli.WazTransaction;

/**
 * @author Steve Mbakop
 *
 */
public class QueueTask extends Task {
	
	/**
	 * The message type has 2 state : add [1] or get [0]
	 */
	private int messageType;
	private WazTransaction transaction;

	/**
	 * @param type
	 * @param timeMs
	 */
	public QueueTask(WazTransaction t, String type) {
		super(type, 1000);
		this.messageType = 0;  //default
		this.transaction = t;
	}
	
	

	public int getMessageType() {
		return messageType;
	}



	public void setMessageType(int messageType) {
		this.messageType = messageType;
	}



	public WazTransaction getTransaction() {
		return transaction;
	}



	public void setTransaction(WazTransaction t) {
		this.transaction = t;
	}



	@Override
	public Task valueOf(String type) {
		//Find the corresponding task in QueueDB and return the task
		return null;
	}

}
