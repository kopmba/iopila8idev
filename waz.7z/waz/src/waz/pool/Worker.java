package waz.pool;

public class Worker implements Runnable {
	
	//Logger LOG = Logger.class.forName(Worker.class);
	
	private final Task task;
	
	public Worker(final Task task) {
		this.task = task;
	}
	
	@Override
	public void run() {
		//LOG.info("{} processing {}", Thread.currentThread().getName(), task.toString());
		try {
			Thread.sleep(task.getAttemptTime());
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
