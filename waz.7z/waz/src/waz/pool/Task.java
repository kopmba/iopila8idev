/**
 * 
 */
package waz.pool;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * @author Steve Mbakop
 *
 */
public abstract class Task {
	
	private static final AtomicInteger ID = new AtomicInteger();
	
	private final int id;
	private final String type;
	private final int attemptTime;
	
	public Task(String type, int timeMs) {
		this.id = ID.incrementAndGet();
		this.type = type;
		this.attemptTime = timeMs;
	}

	public String getType() {
		return type;
	}

	public int getAttemptTime() {
		return attemptTime;
	}

	
	/**
	 * Giving specific name to some task
	 * @param type
	 * @return some Task
	 */
	public abstract Task valueOf(String type);

}
