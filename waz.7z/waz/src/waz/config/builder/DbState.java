/**
 * 
 */
package waz.config.builder;

import database.config.WewazDbState;

/**
 * This class is the principal core to construct and create object
 * in database by setting state of any property bound with JDBC.
 * @author m@rdets
 *
 */
public interface DbState extends WewazDbState {
}
