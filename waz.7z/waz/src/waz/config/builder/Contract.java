package waz.config.builder;

import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import jdk.jfr.Description;
import jdk.jfr.Label;
import jdk.jfr.MetadataDefinition;

/**
 * A contract is a Object specifying a network
 * @author Steve Mbakop
 *
 */
@MetadataDefinition
@Label("Contract")
@Description("Describe a contract at the creation to save to the event file.")
@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.METHOD})
@Inherited
public @interface Contract {
	
	String[] value();

}
