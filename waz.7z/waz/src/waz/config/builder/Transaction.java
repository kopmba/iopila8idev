package waz.config.builder;

import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import jdk.jfr.Description;
import jdk.jfr.Label;
import jdk.jfr.MetadataDefinition;

/**
 * A transaction is a controller || component use to handle request
 * @author Steve Mbakop
 *
 */
@MetadataDefinition
@Label("Transaction")
@Description("Describe a transaction. Used to handle request.")
@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.METHOD})
@Inherited
public @interface Transaction {
	
	String value();
}
