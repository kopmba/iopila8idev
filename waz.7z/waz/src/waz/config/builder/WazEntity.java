/**
 * 
 */
package waz.config.builder;

import main.config.builder.Entity;
import waz.contract.cli.Contract;

/**
 * WazEntity class extends the Entity used as setter to object
 * in order to prepare insertion in relationnal database.
 * @author m@rdets
 *
 */
public class WazEntity extends Entity {
	
	private Entity.EntityBuilder builder;
	
	/**
	 * 
	 * @param builder
	 */
	public WazEntity(EntityBuilder builder) {
		super(builder);
	}

}
