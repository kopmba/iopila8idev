/**
 * 
 */
package waz.config.builder;

import java.time.Instant;

import waz.contract.cli.Contract;
import waz.contract.cli.WazTransaction;

/**
 * This class is used to create sub-object of Contract
 * by specifying the type of Contract.
 * @author m@rdets(slmbakop)
 *
 */
public class EntityContract extends Contract {

	private final String contractName;

	public EntityContract(long id, String sig, String nonce, String cfile, String name) {
		super(id, sig, nonce, cfile);
		contractName = name;
	}
	
	public String getContractName() {
		return contractName;
	}

	@Override
	public Contract valueOf(String name) {
		
		return null;
	}
	
	

}
